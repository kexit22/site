from django.urls import path 
from . import views
from django.urls import path
from .views import home
urlpatterns = [
    path('site/', home, name='site'),
]
